import java.util.LinkedList;
import java.util.List;

import busca.BuscaLargura;
import busca.BuscaProfundidade;
import busca.Estado;
import busca.MostraStatusConsole;
import busca.Nodo;

public class MeuMissionarioCanibal implements Estado {

    private int missionariosEsq;
    private int canibaisEsq;
    private boolean barcoEsq;
    private String acao;

    public MeuMissionarioCanibal(int missionariosEsq, int canibaisEsq, boolean barcoEsq, String acao) {
        this.missionariosEsq = missionariosEsq;
        this.canibaisEsq = canibaisEsq;
        this.barcoEsq = barcoEsq;
        this.acao = acao;
    }

    @Override
    public String getDescricao() {
        return "Problema dos 3 Missionários e 3 Canibais";
    }

    @Override
    public boolean ehMeta() {
        return missionariosEsq == 0 && canibaisEsq == 0 && !barcoEsq;
    }

    @Override
    public int custo() {
        return 1;
    }

    @Override
    public List<Estado> sucessores() {
        List<Estado> sucessores = new LinkedList<>();

        int[][] movimentos = {
            {2, 0},
            {0, 2},
            {1, 1},
            {1, 0},
            {0, 1}
        };

        for (int[] mov : movimentos) {
            int m = mov[0];
            int c = mov[1];

            MeuMissionarioCanibal novoEstado;

            if (barcoEsq) {
                novoEstado = new MeuMissionarioCanibal(
                    missionariosEsq - m,
                    canibaisEsq - c,
                    false,
                    "Leva " + m + "M e " + c + "C para a direita"
                );
            } else {
                novoEstado = new MeuMissionarioCanibal(
                    missionariosEsq + m,
                    canibaisEsq + c,
                    true,
                    "Volta " + m + "M e " + c + "C para a esquerda"
                );
            }

            if (novoEstado.ehValido()) {
                sucessores.add(novoEstado);
            }
        }

        return sucessores;
    }

    private boolean ehValido() {
        int missionariosDir = 3 - missionariosEsq;
        int canibaisDir = 3 - canibaisEsq;

        if (missionariosEsq < 0 || missionariosEsq > 3 || canibaisEsq < 0 || canibaisEsq > 3) {
            return false;
        }

        if (missionariosEsq > 0 && canibaisEsq > missionariosEsq) {
            return false;
        }

        if (missionariosDir > 0 && canibaisDir > missionariosDir) {
            return false;
        }

        return true;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof MeuMissionarioCanibal)) return false;

        MeuMissionarioCanibal outro = (MeuMissionarioCanibal) obj;

        return this.missionariosEsq == outro.missionariosEsq
            && this.canibaisEsq == outro.canibaisEsq
            && this.barcoEsq == outro.barcoEsq;
    }

    @Override
    public int hashCode() {
        return missionariosEsq * 100 + canibaisEsq * 10 + (barcoEsq ? 1 : 0);
    }

    @Override
    public String toString() {
        int missionariosDir = 3 - missionariosEsq;
        int canibaisDir = 3 - canibaisEsq;

        return acao + "\n"
            + "Esquerda [M=" + missionariosEsq + ", C=" + canibaisEsq + "] "
            + "| Barco: " + (barcoEsq ? "Esquerda" : "Direita") + " | "
            + "Direita [M=" + missionariosDir + ", C=" + canibaisDir + "]";
    }

    public static void main(String[] args) throws Exception {
        MeuMissionarioCanibal inicial = new MeuMissionarioCanibal(3, 3, true, "Estado inicial");

        System.out.println("===== BUSCA EM LARGURA =====");
        BuscaLargura bl = new BuscaLargura(new MostraStatusConsole());
        Nodo solucaoLargura = bl.busca(inicial);

        if (solucaoLargura != null) {
            System.out.println("\nSolução encontrada com Busca em Largura:");
            System.out.println(solucaoLargura.montaCaminho());
        } else {
            System.out.println("Nenhuma solucao encontrada com Busca em Largura.");
        }

        System.out.println("\n\n===== BUSCA EM PROFUNDIDADE =====");
        BuscaProfundidade bp = new BuscaProfundidade(new MostraStatusConsole());
        Nodo solucaoProfundidade = bp.busca(inicial);

        if (solucaoProfundidade != null) {
            System.out.println("\nSolucao encontrada com Busca em Profundidade:");
            System.out.println(solucaoProfundidade.montaCaminho());
        } else {
            System.out.println("Nenhuma soluçao encontrada com Busca em Profundidade.");
        }
    }
}